package autoweka;

class TestingPerformanceRunner
{
    public static void main(String[] args){
        TrajectoryPointExtraRunner.main(args);
    }
}
